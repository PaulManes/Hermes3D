# Hermes3Doctor Spec

> First-pass diagnostics plan for Hermes3D deployments so users stop chasing the same setup failures manually.

## Goal

Provide a single diagnostics surface for the common "Hermes3D cannot connect"
or "runtime support looks broken" cases.

The intent is similar to a backend's own `doctor` command, but focused on
Hermes3D's integration points across providers.

## Primary Outcomes

`hermes3doctor` should:

- identify the selected runtime profile/provider
- verify the gateway is reachable
- identify common auth/config mistakes
- surface provider-specific hints without making the whole app provider-specific
- reduce issue-thread back-and-forth

## First-Pass Scope

### Hermes3D Settings / Environment

Checks:

- current runtime profile selection
- gateway URL presence
- token presence when required
- adapter/provider selection
- obvious `.env` misconfiguration

Outputs:

- selected provider/profile
- missing env or token warnings
- suspicious profile precedence warnings

### Gateway Reachability

Checks:

- can the configured gateway URL be reached?
- can Studio proxy the selected gateway?
- does the endpoint respond like a Hermes3D-compatible gateway?

Outputs:

- reachable / unreachable
- timeout / refused / bad handshake
- wrong backend contract warning

### Hermes Checks

Checks:

- Hermes adapter running
- Hermes API reachable at `HERMES_API_URL`
- Hermes model present
- auth key configured if required
- adapter env loaded correctly
- common remote secure-context failures
- common `1008`, `1011`, `1012` close-code patterns

Outputs:

- adapter found / missing
- API reachable / unreachable
- `401` / bad model / bad URL hints
- remote/Tailscale/public tunnel guidance

### Auth / Token Checks

Checks:

- missing Studio access token
- gateway token missing
- invalid API key patterns
- profile says tokened backend but token is absent

Outputs:

- precise missing-token messages
- auth mismatch guidance

### WebSocket / Origin / Secure-Context Checks

Checks:

- localhost vs remote
- secure-context expectations
- browser/origin hints for public/tunneled deployments
- Cloudflare/ngrok/reverse-proxy warning patterns

Outputs:

- websocket handshake guidance
- origin/secure-context notes
- public tunnel caution notes

## Recommended Output Shape

`hermes3doctor` should produce:

- short headline result
- categorized checks
- pass / warn / fail per item
- copy-pasteable next actions

Example:

```text
Hermes3Doctor: WARN

[pass] Runtime profile: Hermes Default
[pass] Gateway URL reachable: ws://localhost:18789
[warn] Hermes API slow to respond: http://localhost:8642
[fail] Gateway token missing for a remote profile
[warn] Secure-context mismatch for public remote setup

Suggested next actions:
1. set the gateway token for this profile in Studio settings
2. confirm HERMES_API_URL points at a healthy Hermes API
3. if using a public tunnel, test local/LAN direct first
```

## Runtime-Profile Awareness

`hermes3doctor` should be designed against the runtime-profile model:

- provider
- runtime profile
- floor binding

That means the doctor should never assume:

- one backend
- one port
- one global runtime mode

Instead it should inspect the currently selected profile and run the
appropriate checks for that provider.

## Provider-Specific Guidance Rules

### Hermes

Focus on:

- adapter process
- Hermes API reachability
- model/config correctness
- auth key presence
- remote websocket setup
- public/tunnel secure-context issues

### Custom Runtime

Focus on:

- gateway contract compatibility
- reachability
- auth
- profile configuration

## Suggested Implementation Order

### PR 1: CLI / Script Scaffold

Add:

- doctor command entrypoint or script
- report formatter
- shared result types

### PR 2: Runtime Profile Checks

Add:

- selected profile inspection
- settings/env parsing
- gateway URL/token checks

### PR 3: Provider Checks

Add:

- Hermes checks
- demo gateway checks
- custom runtime checks

### PR 4: Common Failure Classifiers

Add:

- websocket close-code guidance
- secure-context/origin hints
- reverse-proxy/tunnel notes

## Relationship To Office Systems

`hermes3doctor` should land before more runtime complexity because it will
make debugging:

- multi-runtime support
- floor-to-profile binding
- public remote deployment

much less painful.

This is why it is sequenced ahead of deeper Office Systems feature work.

## V1 Delivery Boundary

`hermes3doctor` v1 should be considered complete when it provides:

- selected-profile diagnostics with optional per-profile probing
- grouped terminal output with clear pass / warn / fail results
- JSON output for automation and issue reporting
- provider-aware checks for Hermes, demo, and custom runtimes
- common failure classification for transport and auth problems
- concrete remediation for local, remote, tunneled, and adapter-backed setups

This keeps v1 reviewable as deployment diagnostics rather than letting it
turn into a full runtime orchestration project.

## V2 Expansion Backlog

After v1 lands, the next doctor-specific expansion should focus on better
diagnosis depth and better operator ergonomics rather than broader scope.

### Higher-Signal Runtime Heuristics

- deeper adapter/API mismatch detection for the Hermes path
- stronger close-code interpretation from real-world failures
- provider-specific contract validation for demo and custom runtimes
- better wrong-model / wrong-adapter mismatch detection

### Tunnel / Proxy Guidance

- Cloudflare-specific websocket and origin remediation
- Tailscale-specific remote deployment guidance
- reverse-proxy fingerprinting and likely-misconfiguration hints
- public-host checks when auth or secure-context expectations are missing

### Output / Workflow Improvements

- richer terminal presentation
- issue-template or bundle-friendly export
- in-app diagnostics panel later, reusing the same JSON report
- optional doctor autofix for safe configuration repairs

### Runtime-Profile Follow-Through

`hermes3doctor` v2 should also benefit from the separate runtime-profile work:

- simultaneous runtime profile visibility
- per-profile health history
- floor-to-profile diagnosis once Office Systems binding is live

## Follow-Up Docs

After this spec, the next planning doc should be:

- floor schema and builder plan

That doc should define the metadata model before any admin-side floor
builder is implemented.
